def connection(ssid, password):
    import network
    import time
    station = network.WlAN(network.STA_IF)
    station.active(True)
    station.connect(ssid, password)
    for attempt in range(50):
        if station.isconnected():
            break
        time.sleep(0.1)
    return station