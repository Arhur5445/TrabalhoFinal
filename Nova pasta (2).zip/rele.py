import machine
import time

rele = machine.Pin(13, machine.Pin.OUT)

while True:
    rele.value(1)
    time.sleep(3)
    rele.value(0)
    time.sleep(3)